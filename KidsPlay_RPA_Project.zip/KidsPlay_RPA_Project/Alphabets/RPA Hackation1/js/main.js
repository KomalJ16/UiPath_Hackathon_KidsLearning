var  vm = new Vue({
    el: '#vue_det',
    data: {
        alphabets: 'B'
    }
 })